package com.nexuscrm.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

private const val BASE_URL = "http://10.0.2.2:8000/"
private val Navy = Color(0xFF14243A)
private val Blue = Color(0xFF246BCE)
private val Bg = Color(0xFFF3F6FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusApp() }
    }
}

@Composable
fun NexusApp() {
    var selected by remember { mutableStateOf("Bosh sahifa") }
    var apiStatus by remember { mutableStateOf("Server holati tekshirilmoqda…") }
    LaunchedEffect(Unit) {
        apiStatus = try {
            withContext(Dispatchers.IO) {
                val req = Request.Builder().url(BASE_URL + "health").build()
                OkHttpClient().newCall(req).execute().use { it.body?.string() ?: "Javob yo‘q" }
            }
            "Server bilan aloqa mavjud"
        } catch (_: Exception) { "Serverga ulanilmadi — backendni ishga tushiring" }
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Bg)) {
        Row(Modifier.fillMaxSize().background(Bg)) {
            Column(Modifier.width(76.dp).fillMaxHeight().background(Navy).padding(vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(22.dp)) {
                Icon(Icons.Default.Layers, null, tint = Color.White, modifier = Modifier.size(30.dp))
                listOf("Bosh sahifa","Mijozlar","Arizalar","Shartnomalar","Hisobot").forEach { item ->
                    IconButton(onClick = { selected = item }) {
                        Icon(when(item) {
                            "Mijozlar" -> Icons.Default.People
                            "Arizalar" -> Icons.Default.Assignment
                            "Shartnomalar" -> Icons.Default.Description
                            "Hisobot" -> Icons.Default.Analytics
                            else -> Icons.Default.Dashboard
                        }, contentDescription = item, tint = if(selected == item) Color(0xFF7FC1FF) else Color.White)
                    }
                }
            }
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Text("NEXUS CRM", color = Navy, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(selected, color = Navy, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                if (selected == "Bosh sahifa") {
                    Text("Xush kelibsiz", color = Color.DarkGray)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("Mijozlar", "—", Modifier.weight(1f))
                        StatCard("Arizalar", "—", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("Tasdiqlangan", "—", Modifier.weight(1f))
                        StatCard("Kutilmoqda", "—", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(18.dp))
                    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Tizim holati", fontWeight = FontWeight.Bold, color = Navy)
                            Spacer(Modifier.height(6.dp))
                            Text(apiStatus, color = Color.DarkGray, fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("Tezkor bo‘limlar", fontWeight = FontWeight.Bold, color = Navy)
                    listOf("Mijoz qo‘shish", "Yangi ariza", "Shartnomalarni ko‘rish").forEach {
                        Card(Modifier.fillMaxWidth().padding(top = 9.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ChevronRight, null, tint = Blue)
                                Text(it, color = Navy)
                            }
                        }
                    }
                } else {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(18.dp)) {
                            Text(selected, fontWeight = FontWeight.Bold, color = Navy, fontSize = 18.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Ushbu modul keyingi bosqichda API bilan to‘liq ulanadi. Backendda mijozlar, arizalar, tasdiqlash va audit endpointlari tayyor.", color = Color.DarkGray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp)) {
            Text(value, color = Navy, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Color.Gray, fontSize = 12.sp)
        }
    }
}
