# NEXUS CRM — Android + backend starter

Independent CRM prototype. No connection to any third-party/company system.

## Included
- Android native app starter (Kotlin + Jetpack Compose)
- FastAPI backend with demo login, role-aware endpoints, customers, applications, approval and audit history
- SQLite for local development
- Basic role model: `operator`, `manager`, `admin`

## Run the backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```
Open `http://127.0.0.1:8000/docs`.

Demo users (password for all: `nexus123`):
- `operator@nexus.local` / operator
- `manager@nexus.local` / manager
- `admin@nexus.local` / admin

**Prototype only:** demo password storage and SQLite setup are for local testing. Before real deployment use HTTPS, strong password hashing, secret management, migrations, backups, rate limiting, and a security review. Do not enter real customer identity, financial, or credit data. Scoring/KATM integrations are intentionally not implemented; connect only through authorized APIs and customer consent.

## Android
Open `android/` in Android Studio, let Gradle sync, then run on an emulator/device.
Set `BASE_URL` in `MainActivity.kt`:
- Android emulator -> `http://10.0.2.2:8000/`
- Physical device -> `http://YOUR_COMPUTER_LAN_IP:8000/`

This starter has a simple dashboard and API health check. Backend API is the source of truth for multi-user workflow.
