from datetime import datetime, timedelta, timezone
from typing import Optional
import sqlite3, secrets, hashlib

from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel, Field

DB = "nexus.db"
app = FastAPI(title="NEXUS CRM API", version="0.1.0",
              description="Independent CRM prototype API")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def now():
    return datetime.now(timezone.utc).isoformat()

def digest(s):
    return hashlib.sha256(s.encode()).hexdigest()

def init():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY, email TEXT UNIQUE, name TEXT, role TEXT, password_hash TEXT
    );
    CREATE TABLE IF NOT EXISTS sessions(
      token TEXT PRIMARY KEY, user_id INTEGER, expires TEXT
    );
    CREATE TABLE IF NOT EXISTS customers(
      id INTEGER PRIMARY KEY, full_name TEXT, phone TEXT, note TEXT, created_by INTEGER, created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS applications(
      id INTEGER PRIMARY KEY, customer_id INTEGER, amount REAL, purpose TEXT,
      status TEXT, created_by INTEGER, assigned_manager INTEGER, created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS audit(
      id INTEGER PRIMARY KEY, actor_id INTEGER, action TEXT, entity TEXT, entity_id INTEGER, detail TEXT, created_at TEXT
    );
    """)
    if con.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        for email, name, role in [
            ("operator@nexus.local","Operator Demo","operator"),
            ("manager@nexus.local","Manager Demo","manager"),
            ("admin@nexus.local","Administrator Demo","admin")]:
            con.execute("INSERT INTO users(email,name,role,password_hash) VALUES(?,?,?,?)",
                        (email,name,role,digest("nexus123")))
    con.commit(); con.close()

init()

class LoginIn(BaseModel):
    email: str
    password: str

class CustomerIn(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    phone: str = Field(min_length=5, max_length=30)
    note: str = ""

class ApplicationIn(BaseModel):
    customer_id: int
    amount: float = Field(gt=0)
    purpose: str = Field(min_length=2, max_length=200)
    assigned_manager: Optional[int] = None

class DecisionIn(BaseModel):
    comment: str = ""

def current_user(authorization: Optional[str]):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Bearer token required")
    token = authorization[7:]
    con = db()
    row = con.execute("""SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id
                         WHERE s.token=? AND s.expires>?""", (token, now())).fetchone()
    con.close()
    if not row: raise HTTPException(401, "Session expired or invalid")
    return dict(row)

def audit(con, user, action, entity, entity_id, detail=""):
    con.execute("INSERT INTO audit(actor_id,action,entity,entity_id,detail,created_at) VALUES(?,?,?,?,?,?)",
                (user["id"],action,entity,entity_id,detail,now()))

@app.get("/health")
def health():
    return {"status":"ok","service":"NEXUS CRM API","time":now()}

@app.post("/auth/login")
def login(data: LoginIn):
    con=db()
    u=con.execute("SELECT * FROM users WHERE email=? AND password_hash=?",
                  (data.email,digest(data.password))).fetchone()
    if not u:
        con.close(); raise HTTPException(401,"Email yoki parol noto‘g‘ri")
    token=secrets.token_urlsafe(32)
    expires=(datetime.now(timezone.utc)+timedelta(hours=12)).isoformat()
    con.execute("INSERT INTO sessions(token,user_id,expires) VALUES(?,?,?)",(token,u["id"],expires))
    con.commit(); con.close()
    return {"access_token":token,"token_type":"bearer","user":{"id":u["id"],"name":u["name"],"email":u["email"],"role":u["role"]}}

@app.get("/me")
def me(authorization: Optional[str]=Header(None)):
    u=current_user(authorization)
    return {"id":u["id"],"name":u["name"],"email":u["email"],"role":u["role"]}

@app.post("/customers")
def create_customer(data: CustomerIn, authorization: Optional[str]=Header(None)):
    u=current_user(authorization); con=db()
    cur=con.execute("INSERT INTO customers(full_name,phone,note,created_by,created_at) VALUES(?,?,?,?,?)",
                    (data.full_name,data.phone,data.note,u["id"],now()))
    cid=cur.lastrowid; audit(con,u,"customer.created","customer",cid,data.full_name)
    con.commit(); con.close()
    return {"id":cid,"status":"created"}

@app.get("/customers")
def customers(authorization: Optional[str]=Header(None)):
    current_user(authorization); con=db()
    rows=con.execute("""SELECT c.id,c.full_name,c.phone,c.note,c.created_at,u.name AS created_by
                        FROM customers c JOIN users u ON u.id=c.created_by ORDER BY c.id DESC""").fetchall()
    con.close(); return [dict(x) for x in rows]

@app.post("/applications")
def create_application(data: ApplicationIn, authorization: Optional[str]=Header(None)):
    u=current_user(authorization); con=db()
    if not con.execute("SELECT id FROM customers WHERE id=?",(data.customer_id,)).fetchone():
        con.close(); raise HTTPException(404,"Customer not found")
    if data.assigned_manager and u["role"] not in ("admin","manager"):
        con.close(); raise HTTPException(403,"Only manager/admin can assign a manager")
    cur=con.execute("""INSERT INTO applications(customer_id,amount,purpose,status,created_by,
                     assigned_manager,created_at,updated_at) VALUES(?,?,?,'pending',?,?,?,?)""",
                    (data.customer_id,data.amount,data.purpose,u["id"],data.assigned_manager,now(),now()))
    aid=cur.lastrowid; audit(con,u,"application.created","application",aid,"pending")
    con.commit(); con.close(); return {"id":aid,"status":"pending"}

@app.get("/applications")
def applications(authorization: Optional[str]=Header(None)):
    u=current_user(authorization); con=db()
    if u["role"] == "operator":
        rows=con.execute("""SELECT a.*,c.full_name AS customer_name FROM applications a
                            JOIN customers c ON c.id=a.customer_id WHERE a.created_by=?
                            ORDER BY a.id DESC""",(u["id"],)).fetchall()
    else:
        rows=con.execute("""SELECT a.*,c.full_name AS customer_name FROM applications a
                            JOIN customers c ON c.id=a.customer_id ORDER BY a.id DESC""").fetchall()
    con.close(); return [dict(x) for x in rows]

@app.post("/applications/{app_id}/decision")
def decide(app_id: int, data: DecisionIn, authorization: Optional[str]=Header(None)):
    u=current_user(authorization)
    if u["role"] not in ("manager","admin"):
        raise HTTPException(403,"Only manager/admin can approve or reject")
    con=db(); row=con.execute("SELECT * FROM applications WHERE id=?",(app_id,)).fetchone()
    if not row: con.close(); raise HTTPException(404,"Application not found")
    if row["status"] != "pending": con.close(); raise HTTPException(409,"Application already decided")
    status="approved" if data.comment.strip().lower() != "reject" else "rejected"
    con.execute("UPDATE applications SET status=?,updated_at=? WHERE id=?",(status,now(),app_id))
    audit(con,u,"application."+status,"application",app_id,data.comment)
    con.commit(); con.close(); return {"id":app_id,"status":status}

@app.get("/audit")
def audit_log(authorization: Optional[str]=Header(None)):
    u=current_user(authorization)
    if u["role"] != "admin": raise HTTPException(403,"Admin only")
    con=db()
    rows=con.execute("""SELECT a.*,u.name AS actor FROM audit a JOIN users u ON u.id=a.actor_id
                        ORDER BY a.id DESC LIMIT 200""").fetchall()
    con.close(); return [dict(x) for x in rows]
