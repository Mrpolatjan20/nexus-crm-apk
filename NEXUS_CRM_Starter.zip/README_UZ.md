# NEXUS CRM — boshlang‘ich professional loyiha

## Android APK
- Kotlin + Android native UI
- Java/Kotlin JVM target = 17
- Login oynasi va rollar: OPERATOR, MANAGER, ADMIN
- Mijozlar, arizalar, tasdiqlash, xodimlar, hisobot/audit
- Lokal SQLite saqlash (internet talab qilmaydi)

## Demo loginlar
- Operator: `operator` / `123456`
- Menejer: `manager` / `123456`
- Administrator: `admin` / `123456`

Bu loginlar faqat lokal prototipni sinash uchun. Haqiqiy ishga tushirishda backendga ulangan JWT autentifikatsiyasi, kuchli parollar, HTTPS va maxfiy kalitlar talab qilinadi.

## Backend
`backend/` ichida FastAPI API mavjud. Ishga tushirish:

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
export NEXUS_SECRET_KEY='uzun-tasodifiy-maxfiy-kalit'
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

API hujjatlari: `http://SERVER:8000/docs`
Birinchi ADMIN foydalanuvchi `/auth/bootstrap-admin` orqali yaratiladi. Serverni internetga chiqarishdan oldin HTTPS, kuchli secret, zaxira nusxa va ma’lumotlar bazasi siyosatini sozlang.

## GitHub Actions
Repo rootida `NEXUS_CRM_Starter.zip` bo‘lishi kerak. `.github/workflows/main.yml` shu arxivni chiqarib, APK yig‘adi. `NEXUS-CRM-APK` artifact ichidan `app-debug.apk` olinadi.
